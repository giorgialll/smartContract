let applicant;
let cAddress,addressSCEmployement, numberOfOffers;
let addressAccount = web3.eth.accounts[0];
let allOffers = [];
let addressNull = "0x0000000000000000000000000000000000000000";
let depositValue = 0;
let web3js;
let idOfferCandidates;
let requestHoursWork = []
let requestHoursID = []

document.getElementById("VisualizzaCandidati").style.display="none";
document.getElementById("InputVersamento").style.display="none";
document.getElementById("InputnuovaOfferta").style.display="none";
document.getElementById("confermaOreRichieste").style.display="none";
document.getElementById("confOre").style.display="none";

document.getElementById("buttonHire").style.display="none";
document.getElementById("numberOffer").style.display="none";

document.getElementById("visualizzaOfferte").style.display="none";
document.getElementById("buttonhideAllOffers").style.display="none";
document.getElementById("buttonhideYourOffers").style.display = "none";
document.getElementById("visualizzaTuoiAnnunci").style.display = "none";


let loadOffers =  function  (address, i,n) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getJobOffer.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    ManagerContract.getSalary.call(i,
                        (err, resSalary) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                res1[5].c[0] = resSalary.toFixed(0);
                                allOffers[i-1] = res1;

                                if( allOffers.length == numberOfOffers && n == 1 ){
                                    showOffer();
                                }
                                if(allOffers.length == numberOfOffers && n ==2){
                                    showYourOffer()
                                }

                            }
                        });
                }
            });
    });
}

let loadContractInfo =  async function (address,n) {
    console.log("loadContractInfo")
    numberOfOffers = 0;
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getNumberOfOffers.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    numberOfOffers = web3.toDecimal(res);
                    let contentRow = $('#numberOffers');
                    contentRow.find(".numberOfworks").text(numberOfOffers);
                    console.log("numberOfOffers",numberOfOffers)
                    loadList(numberOfOffers,n);


                }
            });
    });

}

updateAddressAccount();

recuperaVariabili();

loadContractInfo(cAddress,0)
//loadList(numberOfOffers,0);

console.log("allOff",allOffers)
$(document).ready(function () {
    $("#buttonViewCand").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="block";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("compositionRow2").innerHTML = "";
        document.getElementById("compositionTemplate2").innerHTML = "";
        document.getElementById("noOffers").innerHTML = "";
        document.getElementById("hireWorker").innerHTML = "";
        document.getElementById("hireWorker").className = "";
        document.getElementById('noOffers').className = "";
        document.getElementById("buttonHire").style.display="none";
        document.getElementById("confermaOreRichieste").style.display="none";
        document.getElementById("confOre").style.display="none";

        updateAddressAccount();

    });

});

$(document).ready(function () {
    $("#viewCandidateOffers").click(function () {
        let idOffert = document.getElementById("idOfferCandidates").value;
        idOfferCandidates = document.getElementById("idOfferCandidates").value;

        document.getElementById("idOfferCandidates").value = "";
        console.log("idOffert",idOffert)

        document.getElementById("compositionTemplate2").innerHTML = "";
        document.getElementById("compositionRow2").innerHTML = "";
        document.getElementById("noOffers").innerHTML = "";
        document.getElementById("hireWorker").innerHTML = "";
        document.getElementById("hireWorker").className = "";
        document.getElementById('noOffers').style.display = "none";
        document.getElementById('noOffers').className = "";

        updateAddressAccount();
        console.log("numberOfOffers",numberOfOffers)
        if ((idOffert == "") || (idOffert == "undefined" || idOffert <= 0 || idOffert > numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCandidates").focus();

            return false;
        } else{
            if(allOffers[idOffert-1][1] != addressAccount){
                alert("Non è presente nessuna offerta con il seguente id");
                document.getElementById("buttonHire").style.display="none";

                return false;
            }
            else{

                viewCandidatesOffert(idOffert);
            }


        }

    });

});

let viewCandidatesOffert = function (idOffert) {

    $.getJSON("solidity/employement.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);

        ManagerContract.getApplicantOf.call(idOffert,
            (err, res) => {
                if (err != null) {
                    console.log(err);
                } else {
                    console.log("applicant vuoto", applicant);
                    applicant = res;
                    console.log(" applicant", applicant);

                    showApplicant(idOffert, applicant);



                }
            });
    });

}


const showApplicant = function (idOffert, applicant) {
    const compositionTemplate = $('#compositionTemplate2');
    const compositionRow = $('#compositionRow2');

    let h4 = document.getElementById('h4');
    let div = document.getElementById("numberOffer");

    h4.innerText = "Candidati all'offerta"+idOffert;
    div.appendChild(h4);

    compositionRow.html("");

    if( applicant.length == 0){
        document.getElementById('noOffers').style.display = "block"
        let div = document.getElementById('noOffers');
        let h3 =  document.createElement('h3');
        div.className = "panel panel-default panel-composition";

        h3.innerText = "Nessun candidato"
        div.appendChild(h3);

    }
    else{
        let id = idOfferCandidates;

        let form = $('#VisualizzaCandidati');
        form.find(".idOffer").text(id);

        let b = document.createElement('b');
        let div2 = document.getElementById("compositionTemplate2");
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');
        let br4 = document.createElement('br');
        let br5 = document.createElement('br');
        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');


        div2.appendChild(br2);

        span1.id = "numberWorker";
        span1.className = "numberWorker";
        b.appendChild(span1);
        span2.textContent =". Address worker: ";
        b.appendChild(span2);
        div2.appendChild(b);
        span3.id = "addressApplicant";
        span3.className = "addressApplicant";
        div2.appendChild(span3);
        div2.appendChild(br3);

        for(let i = 0 ; i < applicant.length ; i++){
            console.log("i",i);
            console.log("applicant[i]",applicant[i]);
            compositionTemplate.find(".numberWorker").text(i);
            compositionTemplate.find(".addressApplicant").text(applicant[i]);
            compositionRow.append(compositionTemplate.html());

        }
        let br = document.createElement('br');
        div2.appendChild(br)

        let div = document.getElementById('hireWorker');


        if(allOffers[idOffert-1][0] != addressNull){
            let h4 =  document.createElement('h4');
            let b = document.createElement('b');


            div.className = "panel panel-default panel-composition";

            h4.innerText = "Lavoratore assunto : "
            b.innerText = allOffers[idOffert-1][0]
            h4.appendChild(b);
            div.appendChild(h4);

        }
        else{
            let p = document.createElement('p');
            let input = document.createElement('input');

            div.appendChild(br4);


            p.innerText = "Assumere il lavoratore con ID";

            div.appendChild(p);

            input.className = "form-control";
            input.type = "number";
            input.id= "idHireWorker";
            div.appendChild(input);

            div.appendChild(br5);
            document.getElementById("buttonHire").style.display="block";


        }
        //compositionRow.append(compositionTemplate.html());



    }
}

$(document).ready(function () {
    $("#buttonHire").click(function () {

        let idWorker = document.getElementById("idHireWorker").value;
        document.getElementById("idHireWorker").value = "";

        console.log("idOfferCandidates",idOfferCandidates)
        let idOffert = idOfferCandidates;
        console.log("idWorker",idWorker);
        let addressWorker = applicant[idWorker];
        let lenghtApplicant = applicant.length;
        console.log("applicant",applicant);
        if ((idWorker == "") || (idWorker == "undefined" || idWorker < 0 || idWorker >= lenghtApplicant)) {
            alert("Non è presente nessun lavoratore con il seguente ID "+ idWorker);
            document.getElementById("idOfferCandidates").focus();
            return false;
        } else{
            console.log("idOffert",idOffert);
            console.log("idWorker",idWorker);

            console.log("addressWorker",addressWorker);
            updateAddressAccount();

            if(offerHasExpired(idOffert) == false){
                console.log("allOffers",allOffers);

                if(allOffers[idOffert-1][1] != addressAccount){
                    alert("Non ha creato nessuna offerta con il seguente ID"+ idOffert);
                }
                else{
                    if(allOffers[idOffert-1][0] != addressNull ){
                        alert("E' già stato assunto un lavoratore per l'offerta" + idOffert);
                    }
                    else{
                        hireWorker(addressWorker, idOffert);

                    }

                }
            }
            else{
                alert("Non è più possibile assumere \nL'offerta è scaduta!");
            }
        }

    });
});


let hireWorker = function (addressWorker, idOffert) {

    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(cAddress);
        contract.hireWorker.sendTransaction(addressWorker, idOffert, {
            from: addressAccount,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });
}

$(document).ready(function () {
    $("#buttonPour").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="block";
        document.getElementById("confermaOreRichieste").style.display="none";
        document.getElementById("confOre").style.display="none";

        updateAddressAccount();

        loadValueDeposit();


    });

});
let loadValueDeposit = function (){
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(cAddress);
        ManagerContract.getDepositedAmount.call(
            async (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    depositValue = web3.toDecimal(res);
                    let eth = depositValue / 1000000000000000000 ;
                    console.log("eth", eth)

                    let contentRow = $('#pageEmployer');
                    contentRow.find(".valueDeposit").text(eth);

                }
            });
    });
}

let loadValueDepositCallback = function (callback){
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(cAddress);
        ManagerContract.getDepositedAmount.call(
            async (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    depositValue = web3.toDecimal(res);
                    let eth = depositValue / 1000000000000000000 ;

                    let contentRow = $('#pageEmployer');

                    contentRow.find(".valueDeposit").text(eth);

                    callback();
                }
            });
    });
}



$(document).ready(function () {
    $("#ButtonVersamento").click(function () {
        let valore = document.getElementById("pourEth").value;
        document.getElementById("pourEth").value = "";
        if ((valore == "") || (valore == "undefined")) {
            alert("Il campo Importo è obbligatorio.");
            document.getElementById("pourEth").focus();
            return false;
        }
        else{
            console.log("valore", valore)
            let wei = valore * 1000000000000000000;
            console.log("wei" , wei)
            pourEth(wei);
        }
    });
});

let pourEth = function (valore) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(cAddress);
        contract.pourMoney.sendTransaction(valore, {
            from: addressAccount,
            gas: 400000,
            value: valore
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });
}

$(document).ready(function () {
    $("#buttonAggiungiOff").click(async function () {
        document.getElementById("VisualizzaCandidati").style.display = "none";
        document.getElementById("VisualizzaCandidati").style.display = "none";
        document.getElementById("InputnuovaOfferta").style.display = "block";
        document.getElementById("InputVersamento").style.display = "none";
        document.getElementById("confermaOreRichieste").style.display = "none";
        document.getElementById("confOre").style.display = "none";

        updateAddressAccount();

    });

});


$(document).ready(function () {
    $("#buttonAddOffer").click(async function () {

        loadValueDepositCallback(checkForAddOffer);

    });
});

let checkForAddOffer  = function(){
    let depositInEth = depositValue / 1000000000000000000;
    console.log("depositInEth",depositInEth)
    let datascadenza = document.getElementById("datascadenza").value;
    let nome = document.getElementById("nome").value;
    let informazioni = document.getElementById("informazioni").value;
    let oreLavorative = document.getElementById("oreLavorative").value;
    let salary = document.getElementById("salary").value;
    document.getElementById("datascadenza").value = "";
    document.getElementById("nome").value = "";
    document.getElementById("informazioni").value = "";
    document.getElementById("oreLavorative").value = "";
    document.getElementById("salary").value = "";

    console.log("datascadenza", datascadenza)
    if ((datascadenza == "") || (datascadenza == "undefined")) {
        alert("Il campo Numero Giorni di Validità dell'offerta è obbligatorio.");
        document.getElementById("datascadenza").focus();
        return false;
    } else {
        if ((nome == "") || (nome == "undefined")) {
            alert("Il campo Nome è obbligatorio.");
            document.getElementById("nome").focus();
            return false;
        } else {
            if ((informazioni == "") || (informazioni == "undefined")) {
                alert("Il campo Informazioni è obbligatorio.");
                document.getElementById("informazioni").focus();
                return false;
            } else {
                if ((oreLavorative == "") || (oreLavorative == "undefined")) {
                    alert("Il campo Ore di lavoro è obbligatorio.");
                    document.getElementById("oreLavorative").focus();
                    return false;
                } else {
                    if ((salary == "") || (salary == "undefined")) {
                        alert("Il campo Stipendio è obbligatorio.");
                        document.getElementById("salary").focus();
                        return false;
                    } else {
                        $.getJSON("solidity/JobOfferManager.json", function (cABI) {
                            const ManagerContract = web3.eth.contract(cABI).at(cAddress);
                            ManagerContract.getDepositedAmount.call(
                                async (err, res) => {
                                    if (err != null) {
                                        alert('There was an error fetching the contract.');
                                    } else {
                                        depositValue = web3.toDecimal(res);
                                        if (depositInEth >= salary) {
                                            let weiSalary = salary * 1000000000000000000;
                                            let minutes = oreLavorative * 60;
                                            addOffer(datascadenza, nome, informazioni, minutes, weiSalary);
                                            await loadContractInfo(cAddress,0);


                                        } else {
                                            alert("Credito insufficiente");
                                            return false;

                                        }
                                    }
                                });
                        });




                    }
                }
            }
        }
    }


}

let addOffer = function (datascadenza,nome,informazioni,oreLavorative,salary) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const myfunction = web3.eth.contract(cABI).at(cAddress);

        myfunction.newJob.sendTransaction(datascadenza,nome,informazioni,oreLavorative,salary, {from: addressAccount, gas: 4000000}, function (error, result) {
                if (!error) {
                    console.log(result);
                } else {
                    console.log(error);
                }
            })
    });
}

$(document).ready(function () {
    $("#buttonConfermaOre").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("confermaOreRichieste").style.display="block";
        document.getElementById("confOre").style.display="block";
        document.getElementById("conferma").style.display="none";
        document.getElementById("compositionRow3").innerHTML = "";
        document.getElementById("allRequestHours").innerHTML = "";
        document.getElementById('nessunaRichiesta').innerHTML = "";
        document.getElementById('nessunaRichiesta').className = "";


        updateAddressAccount();
        requestHoursWork = []
        requestHoursID = []
        loadRequestHours(showHours)

    });

});




let loadRequestHours = function (callback) {

    $.getJSON("solidity/employement.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
        ManagerContract.getIdOffersRequestHour.call(
            async (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {

                    requestHoursID = res1;
                    ManagerContract.getRequestHoursArray.call(
                        async (err, res2) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                requestHoursWork = res2;
                                console.log("requestHoursWork->loadRequestHours",requestHoursWork);
                                console.log("requestHoursID->loadRequestHours",requestHoursID);

                                callback(requestHoursID,requestHoursWork);
                            }
                    });
                }
            });
    });
}

let showHours = function (requestHoursID,requestHoursWork) {
    document.getElementById("allRequestHours").innerText ="";
    document.getElementById("compositionRow3").innerText ="";

    let compositionTemplate = $('#compositionTemplate3');
    let compositionRow = $('#compositionRow3');
    let lengthArray= requestHoursID.length;
    let div = document.getElementById("allRequestHours");
    compositionRow.html("");

    if(lengthArray == 0){
        console.log("Nessuna richiestra per poter aggiunger le ore svolte ")
        let h3 =  document.createElement('h3');
        let div2 =  document.getElementById('nessunaRichiesta');

        div2.className = "panel panel-default panel-composition";
        h3.innerText = "Nessuna richiesta"
        div2.appendChild(h3)

    }
    else{

        console.log("entra per visualizzare ")
        let idOffert;
        let b1 = document.createElement('b');
        let b2 = document.createElement('b');
        let b3 = document.createElement('b');
        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        let br = document.createElement('br');
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');


        b1.innerText = "ID Offerta: ";
        div.appendChild(b1);
        span1.className = "idOfferta";
        span1.id = "idOfferta";
        span1.innerText = "?";
        div.appendChild(span1);

        b2.innerText = "  Address worker: ";
        div.appendChild(b2);

        span2.className= "addressLavoratore";
        span2.id= "addressLavoratore";
        span2.innerText = "?";
        div.appendChild(span2);

        b3.innerText= "  Ore da confermare: "
        div.appendChild(b3);

        span3.className = "oreDaCofermare";
        span3.id = "oreDaCofermare";
        span3.innerText = "?";
        div.appendChild(span3);


        div.appendChild(br2);
        div.appendChild(br3);




        for(let i = 0 ; i< lengthArray ; i++) {
            console.log("Entra nel for ")
            idOffert = requestHoursID[i].c[0]+1;
            console.log("idOffert",idOffert)

            for(let j = 0 ;  j < numberOfOffers; j++){
                if( j == (idOffert-1)){
                    compositionTemplate.find(".addressLavoratore").text(allOffers[j][0]);
                }

            }
            let numberHours = (requestHoursWork[i].c[0]) / 60;
            console.log("numberHours",numberHours)
            compositionTemplate.find(".idOfferta").text(idOffert);
            compositionTemplate.find(".oreDaCofermare").text(numberHours);

            if(i == lengthArray-1){
                let p = document.createElement('p');
                let input = document.createElement('input');

                div.appendChild(br);

                p.innerText = "Inserire l'ID dell'offerta per confermare le ore lavorative";
                div.appendChild(p);

                input.className = "form-control";
                input.type = "number";
                input.id = "idOffConferma";

                div.appendChild(input);
                document.getElementById("conferma").style.display="block";
            }
            compositionRow.append(compositionTemplate.html());

        }
    }
}


$(document).ready(function () {
    $("#confirmHours").click(async function () {
        let idOffer = document.getElementById("idOffConferma").value;
        let flag = false;
        updateAddressAccount()
        if ((idOffer == "") || (idOffer == "undefined") || idOffer <= 0 || idOffer > numberOfOffers) {
            alert("Il campo relativo all'ID dell'offerta è obbligatorio.");
            document.getElementById("idOffConferma").focus();
            return false;
        } else {
            if (allOffers[idOffer - 1][1] == addressAccount) {
                console.log("requestHoursID",requestHoursID)
                for(let i = 0 ; i < requestHoursID.length ; i++){
                    if(requestHoursID[i].c[0] == (idOffer-1)){
                        flag = true;
                        console.log("id -> confirmhoures",requestHoursID[i].c[0] )
                        console.log("ore -> confirmhoures",requestHoursWork[i].c[0] )

                        addWorkHours(idOffer, requestHoursWork[i].c[0]);
                        //await viewWorkHoursDone(idOffer);
                    }

                }
                if(flag == false){
                    alert("Inserire un ID valido");
                    document.getElementById("idOffConferma").focus();
                    return false;

                }

            } else {
                alert("Nessuna offerta creata con l'id inserito");
                document.getElementById("idOffConferma").focus();
                return false;

            }

        }
    });
});

let addWorkHours = function (idOffer, ore) {
    $.getJSON("solidity/employement.json", function (cABI) {
        const contract = web3.eth.contract(cABI).at(addressSCEmployement);

        contract.addWorkdays.sendTransaction(idOffer,ore,{
            from: addressAccount,
            gas: 4000000 }, function (error, result) {
            if (!error) {
                console.log(result);

            } else {
                console.log(error);
            }
        })
    });
}

let viewWorkHoursDone = function (idOffer) {
    $.getJSON("solidity/employement.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
        ManagerContract.getHoursDone.call(idOffer,
            async (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    console.log("res1", res1)

                }
            });
    });
}

$(document).ready(function () {
    $("#buttonviewAllOffers").click( async function () {
        document.getElementById("nomeOfferta").innerHTML = "";
        document.getElementById("caratteristicheOfferta").innerHTML="";
        document.getElementById("visualizzaOfferte").style.display = "block";
        document.getElementById("buttonhideAllOffers").style.display = "block";
        document.getElementById("buttonviewAllOffers").style.display = "none";
        document.getElementById("nessunAnnuncio01").className = "";
        document.getElementById("nessunAnnuncio01").innerText = "";
        document.getElementById("caratteristicheOfferta").innerText = "";
        document.getElementById("nomeOfferta").innerText = "";
        await loadContractInfo(cAddress,1);

    });
});

$(document).ready(function () {
    $("#buttonviewYourOffers").click( async function () {

        document.getElementById("nomeOfferta1").innerHTML = "";
        document.getElementById("caratteristicheOfferta1").innerHTML="";
        document.getElementById("buttonhideYourOffers").style.display = "block";
        document.getElementById("buttonviewYourOffers").style.display = "none";
        document.getElementById("nessunAnnuncio").className = "";
        document.getElementById("nessunAnnuncio").innerHTML = "";
        document.getElementById("classNomeOff").className = "";

        updateAddressAccount();
        await loadContractInfo(cAddress,2);

        //document.getElementById("visualizzaTuoiAnnunci").style.display = "block";


    });

});


$(document).ready(function () {
    $("#buttonhideYourOffers").click( function () {
        document.getElementById("nessunAnnuncio").innerHTML = "";
        document.getElementById("nomeOfferta1").innerHTML="";
        document.getElementById("caratteristicheOfferta1").innerHTML="";
        document.getElementById("visualizzaTuoiAnnunci").style.display = "none";
        document.getElementById("buttonhideYourOffers").style.display = "none";
        document.getElementById("buttonviewYourOffers").style.display = "block";
        document.getElementById("nessunAnnuncio").innerHTML = "";
        document.getElementById("nessunAnnuncio").className = "";
        document.getElementById("compositionRow1buttonConfermaOre").innerHTML="";





    });

});
$(document).ready(function () {
    $("#buttonhideAllOffers").click( function () {
        document.getElementById("visualizzaOfferte").style.display="none";
        document.getElementById("buttonhideAllOffers").style.display="none";
        document.getElementById("buttonviewAllOffers").style.display="block";
        document.getElementById("nomeOfferta").innerHTML = "";
        document.getElementById("caratteristicheOfferta").innerHTML="";

    });

});




async function loadList(nOffers,n){
    if( numberOfOffers == 0 && n == 2){
        console.log("numberOfOffers == 0 && n == 2")
        showYourOffer()
    }
    else{
        if( numberOfOffers == 0 && n == 1){
            showOffer()
        }
        else{
            //allOffers = [];
            for(let i = 1 ; i<=nOffers ; i++) {
                console.log("loadList")
                await loadOffers(cAddress, i,n);
            }

        }

    }



}


let showOffer = function () {
    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');


    if(allOffers.length == 0){
        let h3 = document.createElement('h3');
        document.getElementById('visualizzaOfferte').style.display = "block"

        let content = document.getElementById("nessunAnnuncio01");

        content.className ="panel panel-default panel-composition";
        h3.innerText ="Nessun annuncio";
        content.appendChild(h3);

    }
    else{

        let div1 = document.getElementById("nomeOfferta");
        let div2 = document.getElementById("caratteristicheOfferta");
        let h3 = document.createElement('h3');

        let strong1 = document.createElement('strong');
        let strong2 = document.createElement('strong');
        let strong3 = document.createElement('strong');
        let strong4 = document.createElement('strong');
        let strong5 = document.createElement('strong');
        let strong6 = document.createElement('strong');

        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        let span4 = document.createElement('span');
        let span5 = document.createElement('span');
        let span6 = document.createElement('span');

        let br1 = document.createElement('br');
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');
        let br4 = document.createElement('br');
        let br5 = document.createElement('br');
        let br6 = document.createElement('br');
        let br7 = document.createElement('br');




        h3.className = "panel-title";
        h3.id = "panel-title";
        h3.innerText ="Nome dell'offerta"
        div1.appendChild(h3);

        strong1.innerText ="ID : ";
        div2.appendChild(strong1);
        span1.className = "composition-ID";
        span1.id = "composition-ID";
        div2.appendChild(span1);
        div2.appendChild(br1);


        strong2.innerText ="Info : ";
        div2.appendChild(strong2);
        span2.className = "composition-info";
        span2.id = "composition-info";
        div2.appendChild(span2);
        div2.appendChild(br2);


        strong3.innerText ="Ore Lavorative : ";
        div2.appendChild(strong3);
        span3.className = "composition-workhours";
        span3.id = "composition-workhours";
        div2.appendChild(span3);
        div2.appendChild(br3);


        strong4.innerText ="Stipendio : ";
        div2.appendChild(strong4);
        span4.className = "composition-salary";
        span4.id = "composition-salary";
        div2.appendChild(span4);
        div2.appendChild(br4);

        strong5.innerText ="Scadenza : ";
        div2.appendChild(strong5);
        span5.className = "composition-expirationDate";
        span5.id = "composition-expirationDate";
        div2.appendChild(span5);
        div2.appendChild(br5);

        strong6.innerText ="Datore di lavoro : ";
        div2.appendChild(strong6);
        span6.className = "composition-employer";
        span6.id = "composition-employer";
        div2.appendChild(span6);
        div2.appendChild(br6);
        div2.appendChild(br7);

        compositionRow.html("");

        for (let i = 0; i < allOffers.length; i++) {
            console.log("showOffer entra nel for")

            let datascadenza = allOffers[i][6].c[0];
            let a = new Date(datascadenza * 1000);
            let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
            let year = a.getFullYear();
            let month = months[a.getMonth()];
            let date = a.getDate();

            let time = date + '/' + month + '/' + year  ;


            compositionTemplate.find(".panel-title").text(allOffers[i][2]);
            compositionTemplate.find(".composition-info").text(allOffers[i][3]);
            compositionTemplate.find(".composition-ID").text(i+1);
            let ore = allOffers[i][4].c[0] / 60 ;
            compositionTemplate.find(".composition-workhours").text(ore);
            let salary = (allOffers[i][5].c[0]) / 1000000000000000000
            compositionTemplate.find(".composition-salary").text(salary);
            compositionTemplate.find(".composition-expirationDate").text(time);
            compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
            compositionRow.append(compositionTemplate.html());
        }
    }
}


let showYourOffer = function () {
    console.log("showYourOffer")

    let flag = false;
    for (let i = 0; i < allOffers.length; i++) {
        if( allOffers[i][1] == addressAccount) {
            flag = true;
        }
    }
    document.getElementById("nessunAnnuncio").innerHTML = "";

    if(flag){
        let compositionTemplate = $('#compositionTemplate1');
        let compositionRow = $('#compositionRow1');
        let div1 = document.getElementById("nomeOfferta1");
        let div2 = document.getElementById("caratteristicheOfferta1");
        let h3 = document.createElement('h3');
        document.getElementById("nessunAnnuncio").innerText ="";
        document.getElementById("classNomeOff").className = "panel panel-default panel-composition";

        let strong1 = document.createElement('strong');
        let strong2 = document.createElement('strong');
        let strong3 = document.createElement('strong');
        let strong4 = document.createElement('strong');
        let strong5 = document.createElement('strong');
        let strong6 = document.createElement('strong');

        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        let span4 = document.createElement('span');
        let span5 = document.createElement('span');
        let span6 = document.createElement('span');

        let br1 = document.createElement('br');
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');
        let br4 = document.createElement('br');
        let br5 = document.createElement('br');
        let br6 = document.createElement('br');
        let br7 = document.createElement('br');




        h3.className = "panel-title02";
        h3.id = "panel-title";
        h3.style.margin = "0px";
        h3.style.borde = "0px";
        h3.style.padding = "0px";
        h3.innerText ="Nome dell'offerta02";
        div1.appendChild(h3);

        strong1.innerText ="ID : ";
        div2.appendChild(strong1);
        span1.className = "composition-ID02";
        span1.id = "composition-ID02";
        div2.appendChild(span1);
        div2.appendChild(br1);


        strong2.innerText ="Info : ";
        div2.appendChild(strong2);
        span2.className = "composition-info02";
        span2.id = "composition-info02";
        div2.appendChild(span2);
        div2.appendChild(br2);


        strong3.innerText ="Ore Lavorative : ";
        div2.appendChild(strong3);
        span3.className = "composition-workhours02";
        span3.id = "composition-workhours02";
        div2.appendChild(span3);
        div2.appendChild(br3);


        strong4.innerText ="Stipendio : ";
        div2.appendChild(strong4);
        span4.className = "composition-salary02";
        span4.id = "composition-salary02";
        div2.appendChild(span4);
        div2.appendChild(br4);

        strong5.innerText ="Scadenza : ";
        div2.appendChild(strong5);
        span5.className = "composition-expirationDate02";
        span5.id = "composition-expirationDate02";
        div2.appendChild(span5);
        div2.appendChild(br5);

        strong6.innerText ="Lavoratore : ";
        div2.appendChild(strong6);
        span6.className = "composition-worker02";
        span6.id = "composition-worker02";
        div2.appendChild(span6);
        div2.appendChild(br6);
        div2.appendChild(br7);



        compositionRow.html("");

        for (let i = 0; i < allOffers.length; i++) {
            if( allOffers[i][1] == addressAccount){
                console.log("entra")
                console.log("allOffers[i][2]",allOffers[i][2])
                flag = true;
                let datascadenza = allOffers[i][6].c[0];
                let a = new Date(datascadenza * 1000);
                let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
                let year = a.getFullYear();
                let month = months[a.getMonth()];
                let date = a.getDate();
                let time = date + '/' + month + '/' + year  ;

                compositionTemplate.find(".panel-title02").text(allOffers[i][2]);
                compositionTemplate.find(".composition-info02").text(allOffers[i][3]);
                compositionTemplate.find(".composition-ID02").text(i+1);
                let ore = allOffers[i][4].c[0] / 60 ;
                compositionTemplate.find(".composition-workhours02").text(ore);
                let salary = (allOffers[i][5].c[0]) / 1000000000000000000
                console.log("allOffers[i][5].c[0]", allOffers[i][5].c[0])
                compositionTemplate.find(".composition-salary02").text(salary);

                compositionTemplate.find(".composition-expirationDate02").text(time);

                if(allOffers[i][0] != addressNull){
                    compositionTemplate.find(".composition-worker02").text(allOffers[i][0]);
                }
                else{
                    compositionTemplate.find(".composition-worker02").text(" None");

                }

            }
            compositionRow.append(compositionTemplate.html());



        }
        document.getElementById('visualizzaTuoiAnnunci').style.display = "block"


    }
    else{
        console.log("ENTRA ")
        let h3 = document.createElement('h3');
        document.getElementById('visualizzaTuoiAnnunci').style.display = "block"

        let content = document.getElementById("nessunAnnuncio");

        content.className ="panel panel-default panel-composition";
        h3.innerText ="Nessun annuncio da te creato";
        content.appendChild(h3);

    }
}

let offerHasExpired = function (idOfferCand) {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth()+1;
    let yy = today.getFullYear();
    let dataAttuale = dd + '/' + mm + '/'+ yy;

    let datascadenza = allOffers[idOfferCand-1][6].c[0];

    let a = new Date(datascadenza * 1000);
    let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
    let year = a.getFullYear();
    let month = months[a.getMonth()];
    let date = a.getDate();

    let time = date + '/' + month + '/' + year  ;

    let spliTime = time + "" ;
    spliTime = spliTime.split('/') ;

    let splitAttuale = dataAttuale + "";
    splitAttuale = splitAttuale.split('/');
    if(spliTime[2] < splitAttuale[2] ){
        return true;
    }
    else{
        if( spliTime[2] == splitAttuale[2] && spliTime[1] < splitAttuale[1]){
            return true;
        }
        else{
            if(spliTime[2] == splitAttuale[2] ){
                if( spliTime[1] == splitAttuale[1] && spliTime[0] < splitAttuale[0]){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        }
    }
    return false;

}
function recuperaVariabili(){
    // creo l'array che conterrà tutte le variabili con i rispettivi valori
    var variabili = new Array();
    // recupero tutta la querystring nell'url
    var stringUrl = window.location.search;
    // pulisco la stringa dal "?" iniziale
    stringUrl = stringUrl.substring(1);
    // suddivido in un array le varie coppie di variabile e valore
    var listaVariabili = stringUrl.split('&');
    // ciclo su tutte le coppie di variabile e valore e creo l'array finale delle variabili in url
    for(var a=0; a < listaVariabili.length; a++){
        // divido la coppia variabile e valore attraverso il simbolo "="
        var partiVariabile = listaVariabili[a].split('=');
        // inserisco nell'array finale i valori, come chiave dell'array il nome della variabile e come valore chiaramente il valore
        variabili[unescape(partiVariabile[0])] = unescape(partiVariabile[1]);
    }

    cAddress = variabili.addressJobOffer;
    addressSCEmployement = variabili.addressEmployer;
    numberOfOffers= variabili.numberOfOffers;


}
function updateAddressAccount(){
    if (web3.eth.accounts[0] !== addressAccount) {
        addressAccount = web3.eth.accounts[0];
    }
    let contentRow = $('#pageEmployer');
    contentRow.find(".addressAccount").text(addressAccount);

}