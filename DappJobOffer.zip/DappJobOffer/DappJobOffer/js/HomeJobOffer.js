let startApp = async function () {
    if (web3  !== 'undefined') {
        // Use Mist/MetaMask's provider
        web3js= new Web3(web3.currentProvider);
    } else {
        console.log('No web3? You should consider trying MetaMask!')
        // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
        web3js= new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    }

    $(document).ready(function () {
        document.getElementById("ViewOffers").style.display="none";

        $("#buttonSub").click(function () {
            document.getElementById("ViewOffers").style.display="block";
            cAddress = document.getElementById("cAddress").value;


            addressSCEmployement = document.getElementById("cAddressEmployement").value;


            if (web3.isAddress(cAddress) && web3.isAddress(addressSCEmployement) ) {
                checkAddressinSCEmployement(cAddress,setAddressinSCEmployement)

            } else {
                alert('There was an error fetching your accounts.');

            }
        });
    });
}

let addressNull = "0x0000000000000000000000000000000000000000";
let cAddress, addressSCEmployement ;
let myaddress = web3.eth.accounts[0];
let numberOfOffers = 0;
let allOffers = [];


window.ethereum.enable(startApp())


let checkAddressinSCEmployement =  async function (cAddress,callback) {
    numberOfOffers = 0;
    $.getJSON("solidity/employement.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
        ManagerContract.getIsSetJobOfferAddress.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    if(res){
                        console.log("Address null")
                        callback(cAddress,loadContractInfo);
                    }
                    else{
                        ManagerContract.getIsEqualToJobOfferAddress.call(cAddress,
                            (err, res2) => {
                                if (err != null) {
                                    alert('There was an error fetching the contract.');
                                } else {
                                    if(res2){
                                        console.log("address uguali")
                                        loadContractInfo(cAddress)

                                    }
                                    else{
                                        console.log("address diversi")
                                        alert("Non è possibile associare i 2 contratti");
                                        document.getElementById("cAddressEmployement").focus();
                                        return false;

                                    }
                                }
                            });
                    }
                }
            });
    });

}


let setAddressinSCEmployement = function (cAddress,callback) {
    $.getJSON("solidity/employement.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(addressSCEmployement);
        contract.setJobOfferAddress.sendTransaction(cAddress, {
            from: myaddress,
            gas: 4000000 }, function (error, result) {
            if (!error) {
                console.log(result);
                callback(cAddress);
            } else {
                console.log(error);
            }
        })
    });

}

let loadContractInfo =  async function (address) {
    numberOfOffers = 0;
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getNumberOfOffers.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    numberOfOffers = web3.toDecimal(res);
                    let contentRow = $('#numberOffers');
                    contentRow.find(".numberOfworks").text(numberOfOffers);

                    loadList(res);


                }
            });
    });

}



let loadOffers =  function  (address, i) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getJobOffer.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    ManagerContract.getSalary.call(i,
                        (err, resSalary) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                res1[5].c[0] = resSalary.toFixed(0);
                                allOffers[i-1] = res1;

                                if (allOffers.length == numberOfOffers) {
                                    showOffer();
                                }

                            }
                        });
                }
            });
    });
}

let loadList = async function (nof){
    for(let i = 1 ; i<=nof ; i++) {
        await loadOffers(cAddress, i);

    }
}

let showOffer = function () {

    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth()+1;
    let yy = today.getFullYear();



    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');


    compositionRow.html("");

    for (let i = 0; i < allOffers.length; i++) {
        let datascadenza = allOffers[i][6].c[0];

        let a = new Date(datascadenza * 1000);
        let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
        let year = a.getFullYear();
        let month = months[a.getMonth()];
        let date = a.getDate();
        let time = date + '/' + month + '/' + year  ;

        if(year < yy  || year == yy && month < mm || year == yy  && month == mm && date < dd  ){
            if( allOffers[i][0] == addressNull && allOffers[i][5].c[0]  != 0){
                console.log("offerta scaduta "+ (i+1))
                console.log("allOffers[i][1]",allOffers[i][1])
                alert("Annuncio ID : "+ (i+1) +" scaduto\n")
                $.getJSON("solidity/JobOfferManager.json", function (cABI) {

                    const contract = web3.eth.contract(cABI).at(cAddress);
                    contract.moneyReturnsEemployer.sendTransaction(i+1, allOffers[i][1], {
                        from: allOffers[i][1],
                        gas: 4000000
                    }, function (error, result) {
                        if (!error) {
                            console.log(result);

                        } else {
                            console.log(error);
                        }
                    });
                });

            }

        }

        compositionTemplate.find(".panel-title").text(allOffers[i][2]);
        compositionTemplate.find(".composition-info").text(allOffers[i][3]);
        compositionTemplate.find(".composition-ID").text(i+1);
        let ore = allOffers[i][4].c[0] / 60 ;
        compositionTemplate.find(".composition-workhours").text(ore);
        let salary = (allOffers[i][5].c[0]) / 1000000000000000000
        compositionTemplate.find(".composition-salary").text(salary);
        compositionTemplate.find(".composition-expirationDate").text(time);
        compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
        compositionRow.append(compositionTemplate.html());
    }
}

let moneyReturnsEemployer = function(idOffers , addressWorker){

    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(cAddress);
        contract.hireWorker.sendTransaction(addressWorker, idOffert, {
            from: addressAccount,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });



}
let invioDatiWorker = function (){

    let addressJobOffer = document.getElementById("cAddress").value;
    let addressEmployer = document.getElementById("cAddressEmployement").value;


    let url = "http://localhost:63342/DappJobOffer/DappJobOffer/worker.html?addressJobOffer="+addressJobOffer+"&addressEmployer="+addressEmployer+"&numberOfOffers="+numberOfOffers;

    window.open (url);

}


let invioDatiEmployer = function (){

    let addressJobOffer = document.getElementById("cAddress").value;
    let addressEmployer = document.getElementById("cAddressEmployement").value;


    let url = "http://localhost:63342/DappJobOffer/DappJobOffer/Employer.html?addressJobOffer="+addressJobOffer+"&addressEmployer="+addressEmployer+"&numberOfOffers="+numberOfOffers;

    window.open (url);

}