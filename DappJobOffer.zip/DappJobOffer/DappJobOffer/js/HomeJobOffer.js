let addressNull = "0x0000000000000000000000000000000000000000";
let cAddress, addressSCEmployement ;
let myaddress = web3.eth.accounts[0];
let numberOfOffers = 0;
let allOffers = []
let addressAccount;

let startApp = async function () {
    if (web3  !== 'undefined') {
        // Use Mist/MetaMask's provider
        web3js= new Web3(web3.currentProvider);
    } else {
        console.log('No web3? You should consider trying MetaMask!')
        // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
        web3js= new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    }

    $(document).ready(function () {
        document.getElementById("ViewOffers").style.display="none";

        $("#buttonSub").click(function () {
            document.getElementById("ViewOffers").style.display="block";
            cAddress = document.getElementById("cAddress").value;
            addressSCEmployement = document.getElementById("cAddressEmployement").value;


            if (web3.isAddress(cAddress) && web3.isAddress(addressSCEmployement) ) {
                updateAddressAccount();
                checkAddressinSCEmployement(cAddress,setAddressinSCEmployement)

            } else {
                alert('There was an error fetching your accounts.');

            }
        });
    });
}

;


window.ethereum.enable(startApp())


let checkAddressinSCEmployement =  async function (cAddress,callback) {
    numberOfOffers = 0;
    $.getJSON("solidity/employement.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
        ManagerContract.getIsSetJobOfferAddress.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    if(res){
                        console.log("Address null")
                        callback(cAddress,loadContractInfo);
                    }
                    else{
                        ManagerContract.getIsEqualToJobOfferAddress.call(cAddress,
                            (err, res2) => {
                                if (err != null) {
                                    alert('There was an error fetching the contract.');
                                } else {
                                    if(res2){
                                        console.log("address uguali")
                                        loadContractInfo(cAddress)

                                    }
                                    else{
                                        console.log("address diversi")
                                        alert("Non è possibile associare i 2 contratti");
                                        document.getElementById("cAddressEmployement").focus();
                                        return false;

                                    }
                                }
                            });
                    }
                }
            });
    });

}


let setAddressinSCEmployement = function (cAddress,callback) {
    $.getJSON("solidity/employement.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(addressSCEmployement);
        contract.setJobOfferAddress.sendTransaction(cAddress, {
            from: myaddress,
            gas: 4000000 }, function (error, result) {
            if (!error) {
                console.log(result);
                callback(cAddress);
            } else {
                console.log(error);
            }
        })
    });

}

let loadContractInfo =  async function (address) {
    numberOfOffers = 0;
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getNumberOfOffers.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    numberOfOffers = web3.toDecimal(res);
                    let contentRow = $('#numberOffers');
                    contentRow.find(".numberOfworks").text(numberOfOffers);

                    loadList(res);
                }
            });
    });
}



let loadOffers =  function  (address, i) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getJobOffer.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    ManagerContract.getSalary.call(i,
                        (err, resSalary) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                res1[5].c[0] = resSalary.toFixed(0);
                                allOffers[i-1] = res1;

                                if (allOffers.length == numberOfOffers) {
                                    showOffer();
                                }
                            }
                        });
                }
            });

    });

}

let loadList = async function (nof){
    allOffers = [];
    for(let i = 1 ; i<=nof ; i++) {
        await loadOffers(cAddress, i);

    }

}
/*
let showOffer = function () {

    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');

    compositionRow.html("");
    console.log("allOffers",allOffers)
    for (let i = 0; i < allOffers.length; i++) {
        console.log("OFFERTA ID ", i+1)

        $.getJSON("solidity/JobOfferManager.json", function (cABI) {
            const contract = web3.eth.contract(cABI).at(cAddress);
            contract.getIsActiveOffer.call(i+1,
                (err, res1) => {
                    if (err != null) {
                        console.log(err);
                    } else {

                        contract.getIsMoneyIsReturn.call(i+1,
                            (err, res2) => {
                                if (err != null) {
                                    console.log(err);
                                } else {
                                    contract.getExpirationDate.call(i+1,
                                        (err, res3) => {
                                            if (err != null) {
                                                console.log(err);
                                            } else {

                                                //let datascadenza = allOffers[i][6].c[0];
                                                let datascadenza = res3;
                                                let a = new Date(datascadenza * 1000);
                                                let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
                                                let year = a.getFullYear();
                                                let month = months[a.getMonth()];
                                                let date = a.getDate();
                                                let hour = a.getHours();
                                                let minutes = a.getMinutes();

                                                let time = date + '/' + month + '/' + year+ '    h: ' + hour+':'+ minutes ;

                                                if(res1 == false && res2 == false && allOffers[i][0] == addressNull && allOffers[i][1] == addressAccount){
                                                    alert("Annuncio ID : "+ (i+1) +" scaduto\n")
                                                    compositionTemplate.find(".composition-expirationDate").text(time + "  (SCADUTO)");

                                                    contract.moneyReturnsEemployer.sendTransaction(i+1, {
                                                        from: addressAccount,
                                                        gas: 4000000
                                                    }, function (error, result) {
                                                        if (!error) {
                                                            console.log(result);

                                                        } else {
                                                            console.log(error);
                                                        }
                                                    });
                                                }
                                                else{
                                                    compositionTemplate.find(".composition-expirationDate").text(time);
                                                }
                                                compositionTemplate.find(".panel-title").text(allOffers[i][2]);
                                                compositionTemplate.find(".composition-info").text(allOffers[i][3]);
                                                compositionTemplate.find(".composition-ID").text(i+1);
                                                let ore = allOffers[i][4].c[0] / 60 ;
                                                compositionTemplate.find(".composition-workhours").text(ore.toFixed(2));
                                                let salary = (allOffers[i][5].c[0]) / 1000000000000000000
                                                compositionTemplate.find(".composition-salary").text(salary);
                                                //compositionTemplate.find(".composition-expirationDate").text(time);
                                                compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
                                                compositionRow.append(compositionTemplate.html());


                                            }
                                        });



                                }
                            });
                    }

                });
        });
    }
}
*/


let showOffer = function () {
    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');
    document.getElementById("compositionRow").innerHTML = "";


    if(allOffers.length == 0){
        let h3 = document.createElement('h3');
        document.getElementById('visualizzaOfferte').style.display = "block"

        let content = document.getElementById("nessunAnnuncio01");

        content.className ="panel panel-default panel-composition";
        h3.innerText ="Nessun annuncio";
        content.appendChild(h3);

    }
    else{
        document.getElementById("nomeOfferta").innerHTML = "";
        document.getElementById("caratteristicheOfferta").innerHTML = "";
        document.getElementById("compositionRow").innerHTML = "";


        let div1 = document.getElementById("nomeOfferta");
        let div2 = document.getElementById("caratteristicheOfferta");
        let h3 = document.createElement('h3');

        let strong1 = document.createElement('strong');
        let strong2 = document.createElement('strong');
        let strong3 = document.createElement('strong');
        let strong4 = document.createElement('strong');
        let strong5 = document.createElement('strong');
        let strong6 = document.createElement('strong');

        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        let span4 = document.createElement('span');
        let span5 = document.createElement('span');
        let span6 = document.createElement('span');

        let br1 = document.createElement('br');
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');
        let br4 = document.createElement('br');
        let br5 = document.createElement('br');
        let br6 = document.createElement('br');
        let br7 = document.createElement('br');




        h3.className = "panel-title";
        h3.id = "panel-title";
        h3.innerText ="Nome dell'offerta"
        div1.appendChild(h3);

        strong1.innerText ="ID : ";
        div2.appendChild(strong1);
        span1.className = "composition-ID";
        span1.id = "composition-ID";
        div2.appendChild(span1);
        div2.appendChild(br1);


        strong2.innerText ="Info : ";
        div2.appendChild(strong2);
        span2.className = "composition-info";
        span2.id = "composition-info";
        div2.appendChild(span2);
        div2.appendChild(br2);


        strong3.innerText ="Ore Lavorative : ";
        div2.appendChild(strong3);
        span3.className = "composition-workhours";
        span3.id = "composition-workhours";
        div2.appendChild(span3);
        div2.appendChild(br3);


        strong4.innerText ="Stipendio : ";
        div2.appendChild(strong4);
        span4.className = "composition-salary";
        span4.id = "composition-salary";
        div2.appendChild(span4);
        div2.appendChild(br4);

        strong5.innerText ="Scadenza : ";
        div2.appendChild(strong5);
        span5.className = "composition-expirationDate";
        span5.id = "composition-expirationDate";
        div2.appendChild(span5);
        div2.appendChild(br5);

        strong6.innerText ="Datore di lavoro : ";
        div2.appendChild(strong6);
        span6.className = "composition-employer";
        span6.id = "composition-employer";
        div2.appendChild(span6);
        div2.appendChild(br6);
        div2.appendChild(br7);

        compositionRow.html("");

        for (let i = 0; i < allOffers.length; i++) {
            console.log("Offerta", i+1)

            let datascadenza = allOffers[i][6].c[0];
            let a = new Date(datascadenza * 1000);
            let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
            let year = a.getFullYear();
            let month = months[a.getMonth()];
            let date = a.getDate();

            let hour = a.getHours();
            let minutes = a.getMinutes();

            let time = date + '/' + month + '/' + year+ '    h: ' + hour+':'+ minutes ;

            $.getJSON("solidity/JobOfferManager.json", function (cABI) {
                const contract = web3.eth.contract(cABI).at(cAddress);
                contract.getIsActiveOffer.call(i + 1,
                    (err, res1) => {
                        if (err != null) {
                            console.log(err);
                        } else {
                            if(res1 == false) {
                                compositionTemplate.find(".composition-expirationDate").text(time + "  (SCADUTO)");
                            }
                            else{
                                compositionTemplate.find(".composition-expirationDate").text(time);

                            }

                            compositionTemplate.find(".panel-title").text(allOffers[i][2]);
                            compositionTemplate.find(".composition-info").text(allOffers[i][3]);
                            compositionTemplate.find(".composition-ID").text(i+1);
                            let ore = allOffers[i][4].c[0] / 60 ;
                            compositionTemplate.find(".composition-workhours").text(ore.toFixed(2));
                            let salary = (allOffers[i][5].c[0]) / 1000000000000000000
                            compositionTemplate.find(".composition-salary").text(salary);
                            //compositionTemplate.find(".composition-expirationDate").text(time);
                            compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
                            compositionRow.append(compositionTemplate.html());
                        }
                    });
            });
        }
    }
}

let invioDatiWorker = function (){

    let addressJobOffer = document.getElementById("cAddress").value;
    let addressEmployer = document.getElementById("cAddressEmployement").value;


    let url = "http://localhost:63342/DappJobOffer/DappJobOffer/worker.html?addressJobOffer="+addressJobOffer+"&addressEmployer="+addressEmployer+"&numberOfOffers="+numberOfOffers;

    window.open (url);

}


let invioDatiEmployer = function (){

    let addressJobOffer = document.getElementById("cAddress").value;
    let addressEmployer = document.getElementById("cAddressEmployement").value;


    let url = "http://localhost:63342/DappJobOffer/DappJobOffer/Employer.html?addressJobOffer="+addressJobOffer+"&addressEmployer="+addressEmployer+"&numberOfOffers="+numberOfOffers;

    window.open (url);

}

function updateAddressAccount(){
    if (web3.eth.accounts[0] !== addressAccount) {
        addressAccount = web3.eth.accounts[0];
    }
    let contentRow = $('#pageEmployer');
    contentRow.find(".addressAccount").text(addressAccount);

}