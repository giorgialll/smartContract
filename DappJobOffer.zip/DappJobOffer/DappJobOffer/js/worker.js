let cAddress,addressSCEmployement, numberOfOffers;
let addressAccount = web3.eth.accounts[0];
let works;
let allOffers = [];
let web3js;
let applicant;
let yourCandidacies = [];
let addressNull = "0x0000000000000000000000000000000000000000";
let numberCand=0;


document.getElementById("candidatura").style.display="none";
document.getElementById("richiestaOre").style.display="none";
document.getElementById("richiestaOre").style.display="none";
document.getElementById("buttonhideAllOffers").style.display="none";
document.getElementById("lavoriInCorso").style.display="none";
document.getElementById("leTueCandidature").style.display="none";
document.getElementById("visualizzaOfferte").style.display="none";
document.getElementById("nessunAnnuncio01").className = "";
document.getElementById("nessunAnnuncio01").innerText = "";
document.getElementById("caratteristicheOfferta").innerText = "";
document.getElementById("nomeOfferta").innerText = "";



let loadOffers =  function  (address, i,n) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getJobOffer.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    ManagerContract.getSalary.call(i,
                        (err, resSalary) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                res1[5].c[0] = resSalary.toFixed(0);
                                allOffers[i-1] = res1;

                                if( allOffers.length == numberOfOffers && n == 1 ){
                                    showOffer();
                                }
                            }
                        });
                }
            });
    });
}
let loadContractInfo =  async function (address,n,flag) {
    numberOfOffers = 0;
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getNumberOfOffers.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    numberOfOffers = web3.toDecimal(res);
                    let contentRow = $('#numberOffers');
                    contentRow.find(".numberOfworks").text(numberOfOffers);

                    loadList(flag,n);


                }
            });
    });

}

recuperaVariabili();
//Carico le pfferte lavorative ma passo come parametro 0 per non visualizzarle
//loadList(false,0);
loadContractInfo(cAddress,0,false)
updateAddressAccount();

async function loadList(flag,n){
    if(numberOfOffers ==0 && flag){
        showOffer()
    }
    else{
        for(let i = 1; i<=numberOfOffers ; i++) {
            await loadOffers(cAddress, i,n)
        }
    }

}

let loadListCandidancies = async function () {
    numberCand = 0;
    for (let i = 1; i <= numberOfOffers; i++) {
        await loadYourCandidancies(i);
    }
}

let loadListCandidanciesWithoutShow = async function () {
    numberCand = 0;
    for (let i = 1; i <= numberOfOffers; i++) {
        await loadYourCandidanciesWithoutShow(i);
    }
}

let loadYourCandidancies = function(i){
    $.getJSON("solidity/employement.json", async function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);

        ManagerContract.getApplicantOf.call(i,
            (err, res) => {
                if (err != null) {
                    console.log(err);
                } else {
                    applicant = res;
                    for( let j =0 ; j < applicant.length ; j++){
                        if(applicant[j] == addressAccount){
                            numberCand++ ;

                            yourCandidacies.push(i);
                        }
                    }
                    if(yourCandidacies.length == numberCand && i == numberOfOffers){
                        showYourCandidancies(numberCand);
                    }
                }
            });
    });
}


$(document).ready(function () {
    $("#buttonViewCand").click(async function () {
        document.getElementById("candidatura").style.display = "none";
        document.getElementById("richiestaOre").style.display = "none";
        document.getElementById("lavoriInCorso").style.display = "none";
        document.getElementById("nessunLavoro").innerHTML = "";
        document.getElementById("nessunCandidatura").innerHTML = "";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("compositionTemplate5").innerHTML = "";
        document.getElementById("compositionRow5").innerHTML = "";
        document.getElementById("leTueCandidature").style.display="block";
        document.getElementById("buttonWithdraw").style.display="none";
        document.getElementById("ritirareCandidatura").innerHTML = "";
        let div2 = document.getElementById("compositionRow5");
        div2.className ="";

        updateAddressAccount();
        yourCandidacies = [];
        loadListCandidancies();

    });

});


let showYourCandidancies = async function (numberCand) {

    document.getElementById("compositionTemplate5").innerText ="";
    document.getElementById("compositionRow5").innerText ="";
    let compositionTemplate = $('#compositionTemplate5');
    let compositionRow = $('#compositionRow5');
    let lenght = yourCandidacies.length;
    compositionRow.html("");
    let div = document.getElementById("compositionTemplate5");
    let div2 = document.getElementById("compositionRow5");

    if( numberCand > 0) {
        for (let i = 0; i < numberCand; i++) {
            let b1 = document.createElement('b');
            let b2 = document.createElement('b');
            let p1 = document.createElement('p');
            let p2 = document.createElement('p');
            let br =  document.createElement('br');
            let id  = yourCandidacies[i];

            div2.appendChild(br);

            div2.className ="panel panel-default panel-composition";
            b1.innerText = "ID Offerta ";
            div.appendChild(b1);

            p1.innerText = id;
            p1.id = "idyourCand";
            p1.className = "idyourCand";
            div.appendChild(p1);
            b2.innerText = "Nome ";
            div.appendChild(b2);
            p2.innerText = allOffers[id-1][2];
            p2.id = "idyourNameCand";
            p2.className = "idyourNameCand";
            div.appendChild(p2);
            div.appendChild(br);

        }

        document.getElementById("buttonWithdraw").style.display="block";

        let input = document.createElement('input');
        let font =  document.createElement('font');
        let b =  document.createElement('b');
        let br2 =  document.createElement('br');
        let br3 =  document.createElement('br');
        let p3 = document.createElement('p');
        let div3 = document.getElementById("ritirareCandidatura");

        font.color = "#0D275D";
        font.size = "4"
        b.innerText = "Ritirare candidatura";
        font.appendChild(b);
        div3.appendChild(font);
        div3.appendChild(br2);
        p3.innerText ="Inserire l'ID dell'offerta di cui si vuole ritirare la candidatura";
        div3.appendChild(p3);
        input.className = "form-control";
        input.type = "number";
        input.id= "idWithdraw";
        div3.appendChild(input);
        div3.appendChild(br3);
        compositionRow.append(compositionTemplate.html());


    }
    if(lenght == 0){
        let div = document.createElement('div');
        let h3 = document.createElement('h3');
        let br = document.createElement('br');

        let content = document.getElementById("nessunCandidatura");

        content.appendChild(br);
        div.className ="panel panel-default panel-composition";
        content.appendChild(div);
        h3.innerText ="Nessuna candidatura";
        div.appendChild(h3);
    }


}

$(document).ready(function () {
    $("#buttonWithdraw").click(async function () {
        updateAddressAccount();
        yourCandidacies = [] ;
        loadListCandidanciesWithoutShow();

    });

});


let loadYourCandidanciesWithoutShow = function(i){
    let flag = false;
    $.getJSON("solidity/employement.json", async function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);

        ManagerContract.getApplicantOf.call(i,
            (err, res) => {
                if (err != null) {
                    console.log(err);
                } else {
                    applicant = res;
                    for( let j =0 ; j < applicant.length ; j++){
                        if(applicant[j] == addressAccount){
                            numberCand++ ;
                            yourCandidacies.push(i);
                        }
                    }
                    if(yourCandidacies.length == numberCand && i == numberOfOffers){
                        let idOfferCand = document.getElementById("idWithdraw").value;
                        for(let k = 0 ; k < yourCandidacies.length ; k++){
                            if( yourCandidacies[k] == idOfferCand){
                                flag = true;
                                if ((idOfferCand == "") || (idOfferCand == "undefined" || idOfferCand <= 0 || idOfferCand > numberOfOffers)) {
                                    alert("Non esiste nessuna offerta con ID"+id);
                                    document.getElementById("idWithdraw").focus();
                                } else {
                                    if( offerHasExpired(idOfferCand) == false){
                                        if( allOffers[idOfferCand-1][0] != addressNull){
                                            alert("Non è più possibile ritirare la candidatura \nE' stato già assunto un lavoratore");
                                        }
                                        else{
                                            withdrawCandidature(yourCandidacies[k]);
                                        }

                                    }
                                    else{
                                        alert("Non è più possibile ritirare la candidatura \nL'offerta è scaduta!");

                                    }

                                }

                            }

                        }
                        if(flag == false){
                            alert("Non è presente nessuna candidatura per questa offerta");


                        }

                    }


                }
            });

    });







}


let withdrawCandidature = function (idOfferCand) {
    try {
        $.getJSON("solidity/employement.json", function (cABI) {

            const contract = web3.eth.contract(cABI).at(addressSCEmployement);
            updateAddressAccount();
            contract.withdrawCandidacy.sendTransaction(idOfferCand, { from: addressAccount, gas: 4000000 }, function (error, result) {
                if (!error) {

                    console.log(result);
                } else {
                    console.log(error);
                }
            })
        });
    } catch (err) {
        document.getElementById("xvalue").innerHTML = err;
    }

}


$(document).ready(function () {
    $("#buttonAddHours").click(function () {
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="block";
        document.getElementById("lavoriInCorso").style.display="none";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("nessunLavoro").innerHTML = "";
        document.getElementById("nessunCandidatura").innerHTML = "";
        document.getElementById("leTueCandidature").style.display="none";


    });
});

$(document).ready( function () {
    $("#buttonSendCand").click(function () {
        document.getElementById("candidatura").style.display = "block";
        document.getElementById("richiestaOre").style.display = "none";
        document.getElementById("nessunLavoro").innerHTML = "";
        document.getElementById("nessunCandidatura").innerHTML = "";
        document.getElementById("lavoriInCorso").style.display = "none";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("compositionTemplate5").innerHTML = "";
        document.getElementById("compositionRow5").innerHTML = "";
        document.getElementById("leTueCandidature").style.display = "none";
    });
});

$(document).ready( function () {
    $("#buttonSendCandidacy").click(function () {

        updateAddressAccount()
        document.getElementById("nessunLavoro").innerHTML = "";
        let idOfferCand = document.getElementById("idOfferCand").value;

        document.getElementById("idOfferCand").value = "";
        if ((idOfferCand == "") || (idOfferCand == "undefined" || idOfferCand <= 0 || idOfferCand > numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCand").focus();
            return false;
        } else{
            if(allOffers[idOfferCand-1][1] == addressAccount){
                alert("Non è possibile candidarsi.\nOfferta creata con lo stesso account");
                document.getElementById("idOfferCand").focus();
                return false;

            }
            else{
                $.getJSON("solidity/JobOfferManager.json", function (cABI) {
                    const contract = web3.eth.contract(cABI).at(cAddress);
                    contract.getIsActiveOffer.call(idOfferCand,
                        (err, res1) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                $.getJSON("solidity/employement.json", function (cABI) {

                                    const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
                                    ManagerContract.getApplicantOf.call(idOfferCand,
                                        (err, res) => {
                                            if (err != null) {
                                                console.log(err);
                                            } else {
                                                applicant = res;
                                                for (let i = 0; i < applicant.length; i++) {
                                                    if (applicant[i] == addressAccount) {
                                                        alert("Sei già candidato per questa offerta");
                                                        document.getElementById("idOfferCand").focus();
                                                        return false;
                                                    }
                                                }
                                                if(res1 == false){
                                                    alert("Non è più possibile candidarsi \nL'offerta è scaduta! ");
                                                    return false;
                                                }
                                                else{
                                                    workerApplies(idOfferCand);

                                                }

                                            }
                                        });
                                });


                            }
                        });
                });

            }
        }





/*
        if ((idOfferCand == "") || (idOfferCand == "undefined" || idOfferCand <= 0 || idOfferCand > numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCand").focus();
            return false;
        } else {
            if(allOffers[idOfferCand-1][1] == addressAccount){
                alert("Non è possibile candidarsi.\nOfferta creata con lo stesso account");
                document.getElementById("idOfferCand").focus();
                return false;

            }
            else{
                $.getJSON("solidity/employement.json", function (cABI) {

                    const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
                    ManagerContract.getApplicantOf.call(idOfferCand,
                        (err, res) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                applicant = res;
                                for(let i =0 ; i < applicant.length ; i++){
                                    if( applicant[i] == addressAccount){
                                        alert("Sei già candidato per questa offerta");
                                        document.getElementById("idOfferCand").focus();
                                        return false;
                                    }
                                }
                                let today = new Date();
                                let dd = today.getDate();
                                let mm = today.getMonth()+1;
                                let yy = today.getFullYear();
                                let dataAttuale = dd + '/' + mm + '/'+ yy;
                                let datascadenza = allOffers[idOfferCand-1][6].c[0];
                                let a = new Date(datascadenza * 1000);
                                let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
                                let year = a.getFullYear();
                                let month = months[a.getMonth()];
                                let date = a.getDate();

                                let time = date + '/' + month + '/' + year  ;

                                let spliTime = time + "" ;
                                spliTime = spliTime.split('/') ;

                                let splitAttuale = dataAttuale + "";
                                splitAttuale = splitAttuale.split('/');
                                if(spliTime[2] < splitAttuale[2] ){
                                    alert("Non è più possibile candidarsi \nL'offerta è scaduta! ");
                                }
                                else{
                                    if( spliTime[2] == splitAttuale[2] && spliTime[1] < splitAttuale[1]){
                                        alert("Non è più possibile candidarsi \nL'offerta è scaduta!");

                                    }
                                    else{
                                        if(spliTime[2] == splitAttuale[2] ){
                                            if( spliTime[1] == splitAttuale[1] && spliTime[0] < splitAttuale[0]){
                                                alert("Non è più possibile candidarsi \nL'offerta è scaduta!");
                                            }
                                            else{
                                                workerApplies(idOfferCand);
                                            }
                                        }
                                        else{
                                            workerApplies(idOfferCand);
                                        }
                                    }
                                }

                            }
                        })
                });

            }
        }*/
    });
});

let workerApplies = function (idOfferCand) {
    try {
        $.getJSON("solidity/employement.json", function (cABI) {

            const contract = web3.eth.contract(cABI).at(addressSCEmployement);
            updateAddressAccount();
            contract.workerApplies.sendTransaction(idOfferCand , { from: addressAccount, gas: 4000000 }, function (error, result) {
                if (!error) {

                    console.log(result);
                } else {
                    console.log(error);
                }
            })
        });
    } catch (err) {
        document.getElementById("xvalue").innerHTML = err;
    }

}



$(document).ready(function () {
    $("#buttonRequestHours").click(function () {
        let idOffer = document.getElementById("idOffer").value;
        document.getElementById("idOffer").value = "";
        if ((idOffer == "") || (idOffer == "undefined" || idOffer <= 0 || idOffer > numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCand").focus();
            document.getElementById("numberHours").value = "";

            return false;
        }
        else{

            updateAddressAccount();
            let numberHours = document.getElementById("numberHours").value;
            document.getElementById("numberHours").value = "";
            //L'address del lavoratore loggato deve corrsispondere a quello del lavoratore assunto per l'offerta

            $.getJSON("solidity/JobOfferManager.json", function (cABI) {
                const contract = web3.eth.contract(cABI).at(cAddress);
                contract.getAddressWorker.call(idOffer,
                    (err, addressWorker) => {
                        if (err != null) {
                            console.log(err);
                        } else {
                            console.log( "Address", addressWorker);


                            if(addressWorker == addressAccount ){
                                //Trasfromo il numero di ore in minuti
                                let minutes = numberHours * 60 ;
                                console.log("minutes",minutes)
                                requestHours(idOffer,minutes,addressAccount);

                            }
                            else{
                                alert("Nessun lavoro in corso sull'offerta indicata.");
                            }
                        }
                    });
            });



        }


    });

});

let requestHours = function (idOffer,minutes) {

    $.getJSON("solidity/employement.json", function (cABI) {

        const contract = web3.eth.contract(cABI).at(addressSCEmployement);

        contract.requestAdditionalHours.sendTransaction(idOffer, minutes, {
            from: addressAccount,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });

}






$(document).ready(function () {
    $("#buttonAddHours").click(function () {
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="block";
        document.getElementById("lavoriInCorso").style.display="none";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("compositionRow4").className = "";

    });
});



$(document).ready(function () {
    $("#buttonGoingJobs").click(function () {
        document.getElementById("lavoriInCorso").style.display="block";
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="none";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("nessunLavoro").innerHTML = "";
        document.getElementById("nessunCandidatura").innerHTML = "";
        document.getElementById("leTueCandidature").style.display="none";
        document.getElementById("onGoigJobs").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
        document.getElementById("compositionRow4").className = "";
        updateAddressAccount();

        workInprogress();


    });
});

let workInprogress = function () {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const contract = web3.eth.contract(cABI).at(cAddress);
        contract.getApplicantOf.call(addressAccount,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    works = res1;
                    console.log( "works", works);
                    showWorkInProgess();
                }
            });
    });
}


let showWorkInProgess = async function () {

    let compositionTemplate = $('#compositionTemplate4');
    let compositionRow = $('#compositionRow4');

    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const contract = web3.eth.contract(cABI).at(cAddress);
        if( works.length > 0) {
            compositionRow.html("");
            let div = document.getElementById("onGoigJobs");
            let div2 = document.getElementById("compositionRow4");
            let b1 = document.createElement('b');
            let b2 = document.createElement('b');
            let p1 = document.createElement('p');
            let p2 = document.createElement('p');
            let p3 = document.createElement('p');

            div2.className ="panel panel-default panel-composition";

            b1.innerText = "ID Offerta ";
            div.appendChild(b1);

           // p1.innerText = works[i].c[0];
            p1.id = "idOfferInProgress";
            p1.className = "idOfferInProgress";
            div.appendChild(p1);

            b2.innerText = "Nome ";
            div.appendChild(b2);
            //p2.innerText = res1;
            p2.id = "nameOfferInProgress";
            p2.className = "nameOfferInProgress";
            div.appendChild(p2);

            div.appendChild(p3);

            for (let i = 0; i < works.length; i++) {

                contract.getName.call((works[i].c[0]),
                    (err, res1) => {
                        if (err != null) {
                            console.log(err);
                        } else {
                            compositionTemplate.find(".idOfferInProgress").text(works[i].c[0]);
                            compositionTemplate.find(".nameOfferInProgress").text(res1);

                            compositionRow.append(compositionTemplate.html());


                        }

                    });

            }
        }
        else{
            let div = document.createElement('div');
            let h3 = document.createElement('h3');
            let br = document.createElement('br');

            let content = document.getElementById("nessunLavoro");

            content.appendChild(br);
            div.className ="panel panel-default panel-composition";
            content.appendChild(div);
            h3.innerText ="Nessun lavoro";
            div.appendChild(h3);


        }
    });

}

$(document).ready(function () {
    $("#buttonviewAllOffers").click( async function () {


        document.getElementById("visualizzaOfferte").style.display = "block";
        document.getElementById("buttonhideAllOffers").style.display = "block";
        document.getElementById("buttonviewAllOffers").style.display = "none";
        document.getElementById("nessunAnnuncio01").className = "";
        document.getElementById("nessunAnnuncio01").innerText = "";
        document.getElementById("caratteristicheOfferta").innerText = "";
        document.getElementById("nomeOfferta").innerText = "";

        await loadContractInfo(cAddress,1);


    });

});

$(document).ready(function () {
    $("#buttonhideAllOffers").click( function () {
        document.getElementById("visualizzaOfferte").style.display="none";
        document.getElementById("buttonhideAllOffers").style.display="none";
        document.getElementById("buttonviewAllOffers").style.display="block";
        document.getElementById("nomeOfferta").innerHTML = "";
        document.getElementById("caratteristicheOfferta").innerHTML="";

    });

});

function recuperaVariabili(){
    // creo l'array che conterrà tutte le variabili con i rispettivi valori
    var variabili = new Array();
    // recupero tutta la querystring nell'url
    var stringUrl = window.location.search;
    // pulisco la stringa dal "?" iniziale
    stringUrl = stringUrl.substring(1);
    // suddivido in un array le varie coppie di variabile e valore
    var listaVariabili = stringUrl.split('&');
    // ciclo su tutte le coppie di variabile e valore e creo l'array finale delle variabili in url
    for(var a=0; a < listaVariabili.length; a++){
        // divido la coppia variabile e valore attraverso il simbolo "="
        var partiVariabile = listaVariabili[a].split('=');
        // inserisco nell'array finale i valori, come chiave dell'array il nome della variabile e come valore chiaramente il valore
        variabili[unescape(partiVariabile[0])] = unescape(partiVariabile[1]);
    }

    cAddress = variabili.addressJobOffer;
    addressSCEmployement = variabili.addressEmployer;
    numberOfOffers= variabili.numberOfOffers;
}

function updateAddressAccount(){
    if (web3.eth.accounts[0] !== addressAccount) {
        addressAccount = web3.eth.accounts[0];
    }
    let contentRow = $('#pageWorker');
    contentRow.find(".addressAccount").text(addressAccount);

}







let showOffer = function () {
    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');

    if(allOffers.length == 0){
        let h3 = document.createElement('h3');
        let content = document.getElementById("nessunAnnuncio01");
        document.getElementById('visualizzaOfferte').style.display = "block"
        content.className ="panel panel-default panel-composition";
        h3.innerText ="Nessun annuncio";
        content.appendChild(h3);
    }
    else{

        let div1 = document.getElementById("nomeOfferta");
        let div2 = document.getElementById("caratteristicheOfferta");
        let h3 = document.createElement('h3');

        let strong1 = document.createElement('strong');
        let strong2 = document.createElement('strong');
        let strong3 = document.createElement('strong');
        let strong4 = document.createElement('strong');
        let strong5 = document.createElement('strong');
        let strong6 = document.createElement('strong');

        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        let span4 = document.createElement('span');
        let span5 = document.createElement('span');
        let span6 = document.createElement('span');

        let br1 = document.createElement('br');
        let br2 = document.createElement('br');
        let br3 = document.createElement('br');
        let br4 = document.createElement('br');
        let br5 = document.createElement('br');
        let br6 = document.createElement('br');
        let br7 = document.createElement('br');


        h3.className = "panel-title";
        h3.id = "panel-title";
        h3.innerText ="Nome dell'offerta"
        div1.appendChild(h3);

        strong1.innerText ="ID : ";
        div2.appendChild(strong1);
        span1.className = "composition-ID";
        span1.id = "composition-ID";
        div2.appendChild(span1);
        div2.appendChild(br1);


        strong2.innerText ="Info : ";
        div2.appendChild(strong2);
        span2.className = "composition-info";
        span2.id = "composition-info";
        div2.appendChild(span2);
        div2.appendChild(br2);


        strong3.innerText ="Ore Lavorative : ";
        div2.appendChild(strong3);
        span3.className = "composition-workhours";
        span3.id = "composition-workhours";
        div2.appendChild(span3);
        div2.appendChild(br3);


        strong4.innerText ="Stipendio : ";
        div2.appendChild(strong4);
        span4.className = "composition-salary";
        span4.id = "composition-salary";
        div2.appendChild(span4);
        div2.appendChild(br4);

        strong5.innerText ="Scadenza : ";
        div2.appendChild(strong5);
        span5.className = "composition-expirationDate";
        span5.id = "composition-expirationDate";
        div2.appendChild(span5);
        div2.appendChild(br5);

        strong6.innerText ="Datore di lavoro : ";
        div2.appendChild(strong6);
        span6.className = "composition-employer";
        span6.id = "composition-employer";
        div2.appendChild(span6);
        div2.appendChild(br6);
        div2.appendChild(br7);

        compositionRow.html("");

        for (let i = 0; i < allOffers.length; i++) {
            let datascadenza = allOffers[i][6].c[0];

            let a = new Date(datascadenza * 1000);
            let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
            let year = a.getFullYear();
            let month = months[a.getMonth()];
            let date = a.getDate();

            let time = date + '/' + month + '/' + year  ;


            compositionTemplate.find(".panel-title").text(allOffers[i][2]);
            compositionTemplate.find(".composition-info").text(allOffers[i][3]);
            compositionTemplate.find(".composition-ID").text(i+1);
            let ore = allOffers[i][4].c[0] / 60 ;
            compositionTemplate.find(".composition-workhours").text(ore);
            let salary = (allOffers[i][5].c[0]) / 1000000000000000000
            compositionTemplate.find(".composition-salary").text(salary);

            compositionTemplate.find(".composition-expirationDate").text(time);
            compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
            compositionRow.append(compositionTemplate.html());
        }
    }
}

let offerHasExpired = function (idOfferCand) {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth()+1;
    let yy = today.getFullYear();
    let dataAttuale = dd + '/' + mm + '/'+ yy;
    let datascadenza = allOffers[idOfferCand-1][6].c[0];
    let a = new Date(datascadenza * 1000);
    let months = ['1','2','3','4','5','6','7','8','9','10','11','12'];
    let year = a.getFullYear();
    let month = months[a.getMonth()];
    let date = a.getDate();

    let time = date + '/' + month + '/' + year  ;

    let spliTime = time + "" ;
    spliTime = spliTime.split('/') ;

    let splitAttuale = dataAttuale + "";
    splitAttuale = splitAttuale.split('/');

    if(spliTime[2] < splitAttuale[2] ){
        return true;
    }
    else{
        if( spliTime[2] == splitAttuale[2] && spliTime[1] < splitAttuale[1]){
            return true;
        }
        else{
            if(spliTime[2] == splitAttuale[2] ){
                if( spliTime[1] == splitAttuale[1] && spliTime[0] < splitAttuale[0]){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        }
    }
    return false;

}