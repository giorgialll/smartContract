let web3js;
window.addEventListener('load', function () {

    // Checking if Web3 has been injected by the browser (Mist/MetaMask)
    if (web3  !== 'undefined') {
        // Use Mist/MetaMask's provider
        web3js= new Web3(web3.currentProvider);
    } else {
        console.log('No web3? You should consider trying MetaMask!')
        // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
        web3js= new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    }

    // Now you can start your app & access web3 freely:
    window.ethereum.enable(startApp())

});

//creo una letiabile globale per l'address del contratto
let addressWorker;
let cAddress , addressSCEmployement;
let applicant ;
let myaddress = web3.eth.accounts[0];
let numberOfOffers = 0;
let allOffers = [];
let allOffersOrdered = [];
let requestHoursWork = [];
let addressNull = "0x0000000000000000000000000000000000000000";
let workInProgress;









let startApp = async function () {

    //quando il documento è pronto
    $(document).ready(function () {
        document.getElementById("pageEmployer").style.display="none";
        document.getElementById("buttonWorker").style.display="none";
        document.getElementById("buttonEmployer").style.display="none";
        document.getElementById("numberOffers").style.display="none";
        document.getElementById("buttonViewOffers").style.display="none";
        document.getElementById("buttonHideOffers").style.display="none";
        document.getElementById("pageWorker").style.display="none";
        document.getElementById("noOffers").style.display="none";
        document.getElementById("ConfermaOre").style.display="none";
        document.getElementById("lavoriInCorso").style.display="none";



        $("#buttonSub").click(function () {

            cAddress = document.getElementById("cAddress").value;
            addressSCEmployement = document.getElementById("cAddressEmployement").value;


            if (web3js.isAddress(cAddress) && web3js.isAddress(addressSCEmployement) ) {

                setAddressinSCEmployement(cAddress);
                loadContractInfo(cAddress);

            } else {
                alert('There was an error fetching your accounts.');

            }
        });
    });
}

let loadContractInfo =  async function (address) {
    numberOfOffers = 0;
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getNumberOfOffers.call(
            (err, res) => {
                if (err != null) {
                    alert('There was an error fetching the contract.');
                } else {
                    numberOfOffers = web3.toDecimal(res);
                    let contentRow = $('#numberOffers');
                    contentRow.find(".numberOfworks").text(numberOfOffers);

                    console.log("numberOfOffers",numberOfOffers);

                    loadList(res);


                }
            });
    });

}

let displayButtons = function(){
    document.getElementById("buttonWorker").style.display="block";
    document.getElementById("buttonEmployer").style.display="block";
    document.getElementById("buttonViewOffers").style.display="block";


}

let loadOffersPROVA =  function  (address, i) {
    console.log("entra")
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getJobOffer.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    console.log("res1", res1)
                    allOffers[i-1] = res1;


                    console.log("allOffers", allOffers)

                    //allOffers.push({id: i , offer: res1});
                    if (allOffers.length == numberOfOffers) {
                        console.log("employer", allOffers[0][1]);
                        console.log("allOffers", allOffers);

                        showOffer();
                        displayButtons();
                    }
                }
            });
    });
}


//caricamento dalla blockchain dei dati dell'elemento scelto
let loadOffers =  function  (address, i,callback) {
    console.log("loadOffers start"+i)
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const ManagerContract = web3.eth.contract(cABI).at(address);
        ManagerContract.getName.call(i,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    ManagerContract.getInfo.call(i,
                        (err, res2) => {
                            if (err != null) {
                                console.log(err);
                            } else {
                                ManagerContract.getExpirationDate.call(i,
                                    (err, res3) => {
                                        if (err != null) {
                                            console.log(err);
                                        } else {
                                            ManagerContract.getSalary.call(i,
                                                (err, res4) => {
                                                    if (err != null) {
                                                        console.log(err);
                                                    } else {
                                                        ManagerContract.getAddressEmployer.call(i,
                                                            (err, res5) => {
                                                                if (err != null) {
                                                                    console.log(err);
                                                                } else {
                                                                    ManagerContract.getAmountHours.call(i,
                                                                        (err, res6) => {
                                                                            if (err != null) {
                                                                                console.log(err);
                                                                            } else {
                                                                                ManagerContract.getAddressWorker.call(i,
                                                                                    (err, res7) => {
                                                                                        if (err != null) {
                                                                                            console.log(err);
                                                                                        } else {
                                                                                            allOffers.push({
                                                                                                id: i,
                                                                                                expirationDate: res3,
                                                                                                employer: res5,
                                                                                                name: res1,
                                                                                                info: res2,
                                                                                                workhours: res6,
                                                                                                salary: res4,
                                                                                                worker: res7
                                                                                            });
                                                                                            if(allOffers.length == numberOfOffers){
                                                                                                console.log("allOffers.length",allOffers.length);
                                                                                                console.log("allOffers", allOffers);

                                                                                                showOffer();
                                                                                                displayButtons();
                                                                                            }
                                                                                            }
                                                                                    });
                                                                            }
                                                                        });
                                                                }
                                                            });
                                                    }
                                                });
                                        }
                                    });

                            }
                        });
                }
            });
        // }
    });


}




//visualizzazione dati dell'elemento scelto

let loadList = async function (nof){

    //console.log("LOADlist start")
    if(numberOfOffers == 0){
        displayButtons();
    }
    else{
        for(let i = 1 ; i<=nof ; i++) {
            //console.log("loadList "+ i)
            console.log("LOAD LIST -> i ", i);
            //await loadOffers(cAddress, i);
            await loadOffersPROVA(cAddress, i);

        }
    }

   /* for(let i = 1 ; i<=nof ; i++) {
        await loadRequestHours(i);
    }
    console.log("requestHoursWork",requestHoursWork);
    console.log("requestHoursWork",requestHoursWork[3]);*/
}





let showOffer = function () {
    //console.log("showOffer start")
    let compositionTemplate = $('#compositionTemplate');
    let compositionRow = $('#compositionRow');
    compositionRow.html("");
    allOffersOrdered =allOffers;

    /*for(let i = 0 ; i < numberOfOffers; i++){
        for(let j=1 ; j <= numberOfOffers; j++){
            if(allOffers[i].id == j){
                //allOffersOrdered.push(allOffers[i]);
                console.log("allOffers[i].id", allOffers[i].id );
                console.log("j", j );

                allOffersOrdered[j] = allOffers[i];
                //j= numberOfOffers;
            }

        }

    }*/3
    console.log("allOffersOrdered", allOffersOrdered);
    console.log("allOffers",allOffers)

    for(let i = 0 ; i<allOffers.length ; i++) {
        //let anOffer = allOffersOrdered[i];

        //let i = nof;
        $("#panel-title").html(allOffers[i][2]);
        $("#composition-info").html(allOffers[i][3]);
        $("#composition-ID").html(i+1);
        compositionTemplate.find(".composition-workhours").text(allOffers[i][4].c[0]);
        compositionTemplate.find(".composition-salary").text(allOffers[i][5].c[0]);
        compositionTemplate.find(".composition-expirationDate").text(allOffers[i][6].c[1]);
        compositionTemplate.find(".composition-employer").text(allOffers[i][1]);
        compositionRow.append(compositionTemplate.html());
    }

}


let pourEth = function ( ) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const contract = web3js.eth.contract(cABI).at(cAddress);
        contract.pourMoney.sendTransaction(document.getElementById("pourEth").value, {
            from: myaddress,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });

}



$(document).ready(function () {
    $("#ButtonVersamento").click(function () {
        let valore = document.getElementById("pourEth").value;
        if ((valore == "") || (valore == "undefined")) {
            alert("Il campo Importo è obbligatorio.");
            document.getElementById("pourEth").focus();
            return false;
        }
        else{
            pourEth();

        }
    });

});


let addOffer = function ( ) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const myfunction = web3.eth.contract(cABI).at(cAddress);

        myfunction.newJob.sendTransaction(document.getElementById("datascadenza").value,
            document.getElementById("nome").value,
            document.getElementById("informazioni").value,
            document.getElementById("oreLavorative").value,
            document.getElementById("salary").value, {from: myaddress, gas: 4000000}, function (error, result) {
                if (!error) {
                    console.log(result);
                } else {
                    console.log(error);
                }
            })
    });


}

$(document).ready(function () {
    $("#buttonAddOffer").click(function () {
        let datascadenza = document.getElementById("datascadenza").value;
        let nome = document.getElementById("nome").value;
        let informazioni =  document.getElementById("informazioni").value;
        let oreLavorative = document.getElementById("oreLavorative").value;
        let salary = document.getElementById("salary").value;

        if ((datascadenza == "") || (datascadenza == "undefined")) {
            alert("Il campo Numero Giorni di Validità dell'offerta è obbligatorio.");
            document.getElementById("datascadenza").focus();
            return false;
        }
        else{
            if ((nome == "") || (nome == "undefined")) {
                alert("Il campo Nome è obbligatorio.");
                document.getElementById("nome").focus();
                return false;
            }
            else{
                if ((informazioni == "") || (informazioni == "undefined")) {
                    alert("Il campo Informazioni è obbligatorio.");
                    document.getElementById("informazioni").focus();
                    return false;
                }
                else{
                    if ((oreLavorative == "") || (oreLavorative == "undefined")) {
                        alert("Il campo Ore di lavoro è obbligatorio.");
                        document.getElementById("oreLavorative").focus();
                        return false;
                    }
                    else{
                        if ((salary == "") || (salary == "undefined")) {
                            alert("Il campo Stipendio è obbligatorio.");
                            document.getElementById("salary").focus();
                            return false;
                        }
                        else{
                            addOffer();


                        }

                    }

                }

            }

        }


    });

});

let setAddressinSCEmployement = function ( ) {
    $.getJSON("solidity/employement.json", function (cABI) {

        const contract = web3js.eth.contract(cABI).at(addressSCEmployement);
        contract.setJobOfferAddress.sendTransaction(document.getElementById("cAddress").value, {
             from: myaddress,
             gas: 4000000 }, function (error, result) {
            if (!error) {
                 console.log(result);
             } else {
                 console.log(error);
             }
         })
    });

}


$(document).ready(function () {
    $("#buttonEmployer").click(function () {

        document.getElementById("pageEmployer").style.display="block";
        document.getElementById("pageWorker").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("hireWOrker").style.display="none";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("confermaOreRichieste").style.display="none";



    });

});

$(document).ready(function () {
    $("#buttonWorker").click(function () {

        document.getElementById("pageWorker").style.display="block";
        document.getElementById("pageEmployer").style.display="none";
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="none";
    });

});

$(document).ready(function () {
    $("#buttonViewOffers").click(function () {
        document.getElementById("numberOffers").style.display="block";
        document.getElementById("buttonHideOffers").style.display="block";
        document.getElementById("ViewOffers").style.display="block";
        document.getElementById("numberOffers").style.display="block";




    });

});
$(document).ready(function () {
    $("#buttonHideOffers").click(function () {
        document.getElementById("ViewOffers").style.display="none";
        document.getElementById("numberOffers").style.display="none";


    });

});


let workerApplies = function ( ) {
    try {
        $.getJSON("solidity/employement.json", function (cABI) {

            const contract = web3.eth.contract(cABI).at(addressSCEmployement);
            contract.workerApplies.sendTransaction(document.getElementById("idOfferCand").value,document.getElementById("addressWorkerCand").value , { from: myaddress, gas: 4000000 }, function (error, result) {
                if (!error) {
                    console.log(result);
                } else {
                    console.log(error);
                }
            })
        });
    } catch (err) {
        document.getElementById("xvalue").innerHTML = err;
    }

}

$(document).ready( function () {
    $("#buttonSendCandidacy").click(function () {
        let idOfferCand = document.getElementById("idOfferCand").value;
        let addressWorkerCand = document.getElementById("addressWorkerCand").value;

        if ((idOfferCand == "") || (idOfferCand == "undefined" || idOfferCand <= 0 || idOfferCand> numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCand").focus();
            return false;
        } else {
            if ((addressWorkerCand == "") || (addressWorkerCand == "undefined" )) {
                alert("Il campo Adress è obbligatorio");
                document.getElementById("addressWorkerCand").focus();
                return false;
            }
            else {
                if (web3js.isAddress(addressWorkerCand)) {
                    workerApplies();
                } else {
                    alert('Inserire un Address valido');

                }

            }



        }

    });

});


$(document).ready(function () {
    $("#viewCandidateOffers").click(function () {
        let idOffert = document.getElementById("idOfferCandidates").value;
        if ((idOffert == "") || (idOffert == "undefined" || idOffert <= 0 || idOffert > numberOfOffers)) {
            alert("Il campo ID Offerta non è valido!");
            document.getElementById("idOfferCandidates").focus();
            return false;
        } else{
            viewCandidatesOffert(idOffert);
            document.getElementById("hireWOrker").style.display = "block";

        }

    });

});

let viewCandidatesOffert = function (idOffert) {

    $.getJSON("solidity/employement.json", function (cABI) {

        const ManagerContract = web3js.eth.contract(cABI).at(addressSCEmployement);

        ManagerContract.getApplicantOf.call(idOffert,
            (err, res) => {
                if (err != null) {
                    console.log(err);
                } else {
                    console.log("applicant vuoto", applicant);
                    applicant = res;
                    console.log(" applicant", applicant);

                    if( applicant.length == 0){
                        document.getElementById("noOffers").style.display="block";
                        document.getElementById("hireWOrker").style.display = "none";

                    }
                    else{
                        showApplicant(idOffert, applicant);
                    }


                }
            });

    });

}

const showApplicant = function (idOffert, applicant) {
    const compositionTemplate = $('#compositionTemplate2');
    const compositionRow = $('#compositionRow2');

    //console.log("applicant",applicant);
    //console.log("applicant.length",applicant.length);
    //console.log("applicant[idOffert].length",applicant[idOffert].length);

    compositionRow.html("");

    let b = document.getElementsByTagName('b');
    let div = document.getElementById("compositionTemplate2");
    let br = document.getElementsByTagName('br');
    let span= document.getElementsByTagName('span');
    div.appendChild(br[0]);
    div.appendChild(br[1]);

    span[0].id = "numberWorker";
    span[0].className = "numberWorker";
    b[0].appendChild(span[0]);
    span[1].textContent ="Address worker: ";
    b[0].appendChild(span[1]);
    div.appendChild(b[0]);
    span[2].id = "addressApplicant";
    span[2].className = "addressApplicant";
    div.appendChild(span[2]);
    div.appendChild(br[2]);

    /*
    let div2 = document.getElementById("hireWOrker");
    let p = document.createElement("p");
    let input = document.createElement("input");
    let button = document.createElement("button");
    console.log("input",input );

    p.innerText = "Assumere il lavoratore con ID";
    div2.appendChild(p);
    input.id = "idHireWorker";
    input.type = "text";
    input.className = "form-control";
    console.log("input",input );

    div2.appendChild(br[2]);
    div2.appendChild(input);
    div2.appendChild(br[4]);
    button.type = "reset";
    button.id = "buttonHire";
    button.className = "btn btn-primary";
    button.textContent = "Accetta candidatura";
    div2.appendChild(button);
    div2.appendChild(br[4]);*/


    for(let i = 0 ; i < applicant.length ; i++){
        console.log("i",i);
        console.log("applicant[i]",applicant[i]);
        compositionTemplate.find(".numberWorker").text(i);
        compositionTemplate.find(".addressApplicant").text(applicant[i]);

        compositionRow.append(compositionTemplate.html());
    }

    document.getElementById("hireWOrker").style.display = "block";


}
$(document).ready(function () {
    $("#buttonHire").click(function () {
        console.log(" ENTRA ");
        document.getElementById("hireWOrker").style.display="block";
        let idWorker = document.getElementById("idHireWorker").value;
        let idOffert = document.getElementById("idOfferCandidates").value;
        console.log("idWorker",idWorker);
        let addressWorker = applicant[idWorker];
        console.log("idOffert",idOffert);
        console.log("addressWorker",addressWorker);
        hireWorker(addressWorker, idOffert);

    });

});


let hireWorker = function (addressWorker, idOffert) {

    $.getJSON("solidity/JobOfferManager.json", function (cABI) {

        const contract = web3js.eth.contract(cABI).at(cAddress);
        contract.hireWorker.sendTransaction(addressWorker, idOffert, {
            from: myaddress,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });
}



let requestHours = function (idOffer,numberHours,addressWorker) {
    $.getJSON("solidity/employement.json", function (cABI) {

        const contract = web3js.eth.contract(cABI).at(addressSCEmployement);
        contract.requestAdditionalHours.sendTransaction(idOffer, numberHours,addressWorker, {
            from: myaddress,
            gas: 4000000
        }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        });
    });

}

$(document).ready(function () {
    $("#buttonRequestHours").click(function () {
        let idOffer = document.getElementById("idOffer").value;
        let addressWorker = document.getElementById("addressWorker").value;
        let numberHours = document.getElementById("numberHours").value;
        let id;
        for(let i = 0 ; i < numberOfOffers; i++){
            if(allOffers[i].id == idOffer){
                id = i;
            }
        }
        console.log("allOffers",allOffers);
        console.log("idOffer", id);
        console.log("allOffers[id].worker", allOffers[id].worker);
        console.log("addressWorker",addressWorker)

        if(allOffers[id].worker == addressWorker ){
            requestHours(id,numberHours,addressWorker);

        }
        else{
            alert("Address non corrispondente al'Id dell'offerta!");
        }
    });

});

$(document).ready(function () {
    $("#buttonSendCand").click(function () {
        document.getElementById("candidatura").style.display="block";
        document.getElementById("richiestaOre").style.display="none";

    });

});
$(document).ready(function () {
    $("#buttonAddHours").click(function () {
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="block";
        document.getElementById("lavoriInCorso").style.display="none";
        document.getElementById("compositionTemplate4").innerHTML = "";
        document.getElementById("compositionRow4").innerHTML = "";
    });

});



$(document).ready(function () {
    $("#buttonViewCand").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="block";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("ConfermaOre").style.display="none";
        document.getElementById("compositionRow2").innerHTML = "";
        document.getElementById("hireWOrker").style.display = "none";

    });

});

$(document).ready(function () {
    $("#buttonPour").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="block";
        document.getElementById("ConfermaOre").style.display="none";
    });

});
$(document).ready(function () {
    $("#buttonAggiungiOff").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="block";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("ConfermaOre").style.display="none";

    });

});

$(document).ready(function () {
    $("#buttonConfermaOre").click(function () {
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("VisualizzaCandidati").style.display="none";
        document.getElementById("InputnuovaOfferta").style.display="none";
        document.getElementById("InputVersamento").style.display="none";
        document.getElementById("ConfermaOre").style.display="block";
        document.getElementById("confermaOreRichieste").style.display="block";
        loadHoursList();

    });

});

let loadHoursList = async function () {
    if (numberOfOffers != 0) {
        for (let i = 0; i < numberOfOffers; i++) {
            await loadAddressWorker(i);
            console.log("id" , i);
        }
    }

}

let loadAddressWorker = function( idOffer){
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(cAddress);
        ManagerContract.getAddressWorker.call(idOffer,
            async (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    addressWorker = res1;
                    console.log("addressWorker", addressWorker);
                    if (addressWorker != addressNull) {
                        console.log("entra");
                        await loadRequestHours(idOffer);
                    }

                }
            });
    });
}


let loadRequestHours = function (idOffer) {

    $.getJSON("solidity/employement.json", function (cABI) {
        const ManagerContract = web3.eth.contract(cABI).at(addressSCEmployement);
        ManagerContract.getRequestHours.call(idOffer,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {

                    requestHoursWork.push({id:idOffer , ore: res1});
                    console.log("requestHoursWork", requestHoursWork)

                    showHours();

                    /*if(requestHoursWork.length == numberOfOffers){
                        console.log("requestHoursWork", requestHoursWork)
                        for(let i =0 ; i < numberOfOffers ;i++){
                            console.log("requestHoursWorkID", requestHoursWork[i].id);
                            console.log("requestHoursWorkORE", requestHoursWork[i].ore.c[0]);

                        }

                        //showHours();

                    }*/
                }
            });
    });
}
let showHours = function () {

    let compositionTemplate = $('#compositionTemplate3');
    let compositionRow = $('#compositionRow3');
    let idOffert;
    compositionRow.html("");


    for(let i = 0 ; i< requestHoursWork.length ; i++) {
        idOffert = requestHoursWork[i].id;

        for(let j = 0 ;  j < numberOfOffers; j++){
            if( allOffers[j].id == idOffert){
                compositionTemplate.find(".addressLavoratore").text(allOffers[j].worker);
            }

        }
        compositionTemplate.find(".idOfferta").text(idOffert);
        compositionTemplate.find(".oreDaCofermare").text(requestHoursWork[i].ore.c[0]);

        compositionRow.append(compositionTemplate.html());
    }
}

$(document).ready(function () {
    $("#confirmHours").click(function () {
        let idOffer = document.getElementById("idOffConferma").value;
        for(let i = 0; i < requestHoursWork.length; i++){
            if(requestHoursWork[i].id == idOffer){
                console.log("Id offerta", idOffer);
                console.log("Ore", requestHoursWork[i].ore.c[0]);

                addWorkHours(idOffer,requestHoursWork[i].ore.c[0]);
            }
        }
    });
});

let addWorkHours = function (idOffer, numOre) {
    $.getJSON("solidity/employement.json", function (cABI) {
        const contract = web3js.eth.contract(cABI).at(addressSCEmployement);
        contract.addWorkdays.sendTransaction(idOffer,numOre,{
            from: myaddress,
            gas: 4000000 }, function (error, result) {
            if (!error) {
                console.log(result);
            } else {
                console.log(error);
            }
        })
    });
}



$(document).ready(function () {
    $("#buttonGoingJobs").click(function () {
        document.getElementById("lavoriInCorso").style.display="block";
        document.getElementById("candidatura").style.display="none";
        document.getElementById("richiestaOre").style.display="none";

    });
});

$(document).ready(function () {
    $("#confirmAdress").click(function () {
        let addressWorker = document.getElementById("aWorker").value;
        workInprogress(addressWorker);


    });
});

let workInprogress = function (addressWorker) {
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const contract = web3.eth.contract(cABI).at(cAddress);
        contract.getApplicantOf.call(addressWorker,
            (err, res1) => {
                if (err != null) {
                    console.log(err);
                } else {
                    workInProgress = res1;
                    console.log( "workInProgress", workInProgress);
                    showWorkInProgess();
                }
            });
    });
}

let showWorkInProgess = async function () {

    let compositionTemplate = $('#compositionTemplate4');
    let compositionRow = $('#compositionRow4');

    compositionRow.html("");
    $.getJSON("solidity/JobOfferManager.json", function (cABI) {
        const contract = web3js.eth.contract(cABI).at(cAddress);
        for (let i = 0; i < workInProgress.length; i++) {

            contract.getName.call((workInProgress[i].c[0]),
                (err, res1) => {
                    if (err != null) {
                        console.log(err);
                    } else {
                        let b = document.getElementsByTagName('b');
                        let div = document.getElementById("compositionTemplate4");
                        let p = document.getElementsByTagName('p');
                        let br = document.getElementsByTagName('br');

                        console.log("b",b)


                        b[0].innerText = "ID Offerta ";
                        div.appendChild(b[0]);

                        p[0].innerText = workInProgress[i].c[0];
                        p[0].id = "idOfferInProgress";
                        p[0].className = "idOfferInProgress";
                        div.appendChild(p[0]);

                        b[1].innerText = "Nome ";
                        div.appendChild(b[1]);

                        p[1].innerText = res1;
                        p[1].id = "idOfferInProgress";
                        p[1].className = "idOfferInProgress";
                        div.appendChild(p[1]);
                        div.appendChild(br[0]);



                        //compositionTemplate.find(".idOfferInProgress").text(workInProgress[i].c[0]);
                        //compositionTemplate.find(".nameOfferInProgress").text(res1);

                        compositionRow.append(compositionTemplate.html());
                    }
                });
        }
    });

}






